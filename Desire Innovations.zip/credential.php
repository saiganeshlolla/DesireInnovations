<?php
define('EMAIL','rushikitla300@gmail.com');
define('pass','Rushik@123');
?>